/*
 * Copyright (c) 27/9/2020.
 * created by Mateo Pinzon, Harrison Diaz y Juan Jose Ariza
 * All rights reserved
 */

package models;
/**
 * Esta clase enum para saber cual temporada esta
 * @Author Mateo Pinzon, Harrison Diaz y Juan Ariza
 * @Date 27/09/2020
 */
public enum Season {
    ALTA, BAJA
}
